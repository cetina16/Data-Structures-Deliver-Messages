//
//  BaseStation - Deliver the Message
//
//  Created by ismail bilgen on 17.12.2019.
//  Copyright © 2019 ibilgen. All rights reserved.
//

#include <iostream>
#include <string.h>
#include <stdlib.h> 
#include <iomanip>  
#include <fstream>

using namespace std;

//
//  stack.hpp
//

struct Snode{
    int id;
    Snode * next;
};

struct Stack{
    Snode * head;
    void create();
    void makeEmpty();
    void push(int);
    int pop();
    bool isEmpty();
    void print();
};

//
//  stack.cpp
//

void Stack::create(){
    head = NULL;
}

bool Stack::isEmpty(){
    return head==NULL;
}

void Stack::push(int id){
    Snode * newNode = new Snode;
    newNode->id = id;
    newNode->next = head;
    head = newNode;
}

int Stack::pop(){
    if(head == NULL){
        return -1;
    }
    int value = head->id;
    Snode * temp = head;
    head = head->next;

    delete temp;

    return value;
}

void Stack::print(){
    Snode * p = head;
    int i = 1;

    while(p){
        // cout << i << " " << p->name << endl;
        if(p->next){
            cout << p->id;
            cout << " ";
        }else{
            cout << "mh_" << p->id;
        }
        p = p->next;
        i++;
    }
    //cout << endl;
}

void Stack::makeEmpty(){
    while(head != NULL){
        Snode * temp = head;
        head = head->next;
        delete temp;
    }
    return;
}

//
//  main.cpp
//

// Global Variables
Stack path_s;

struct MobileHost{
    int id;
    MobileHost * next;
};
typedef MobileHost MH;

struct BaseStation{
    int id;
    BaseStation *child;
    BaseStation *next;
    MobileHost * mh;
};
typedef BaseStation BS;

struct Tree{
    BaseStation *root; // central controller
    void create();
    void close();
    void emptytree(BaseStation *);
    void addBaseStation(int, int);
    void addMobileHost(int, int);
    void traversePreorder(BaseStation *);
    BaseStation * getBS(BaseStation *, int);
    MobileHost * getMH(BaseStation *, int); // root and targetid
    void read_fromfile();
};
typedef Tree Network;

void Tree::create(){
    root = new BaseStation;
    root->id = 0;
    root->child = NULL;
    root->next = NULL;
    root->mh = NULL;
}

void Tree::close(){
    traversePreorder(root);
    emptytree(root);
}

void Tree::emptytree(BaseStation *f){
    if(f){
        if (f->child != NULL){
            emptytree(f->child);
            f->child = NULL;
        }
        if (f->next != NULL){
            emptytree(f->next);
            f->next = NULL;
        }
        delete f;
    }
}

void Tree::addBaseStation(int id, int parentid){
    
    // Create a new folder node
    BaseStation * newfolder = new BaseStation;
    newfolder->id = id;
    newfolder->child = NULL;
    newfolder->next = NULL;
    newfolder->mh = NULL;
    
    BaseStation * parentfolder = getBS(root, parentid);
    if(parentfolder == NULL){
        //cout << "Parent node does not exist" << endl;
        return;
    }
    
    if(parentfolder->child == NULL){
        parentfolder->child = newfolder;
    }else{
        BaseStation * sub = parentfolder->child;
        while(sub->next){
            sub = sub->next;
        }
        sub->next = newfolder;
    }
    //cout << "BS " << id << " is added." << endl;
}

void Tree::addMobileHost(int id, int parentid){
    // Create a new doc node
    MobileHost * mh = new MobileHost;
    mh->id = id;
    mh->next = NULL;
    
    BaseStation * parentfolder = getBS(root, parentid);
    // cout << endl;
    if(parentfolder == NULL){
        //cout << "Parent node does not exist" << endl;
        return;
    }
    if(parentfolder->mh == NULL){
        parentfolder->mh = mh;
    }else{
        MobileHost * temp = parentfolder->mh;
        while(temp->next){
            temp = temp->next;
        }
        temp->next = mh;
    }
    //cout << "MH: " << mh->id << " is added." << endl;
}

bool out = false;
BaseStation * Tree::getBS(BaseStation * bs, int searchid){
    
    if(out) // write visited nodes
        cout << bs->id << " ";
    
    BaseStation * foundBS = NULL;
    if(bs->id == searchid){
        path_s.push(bs->id);
        return bs; // foundBS
    }
    if(bs->child){
        if((foundBS = getBS(bs->child, searchid))){
            path_s.push(bs->id);
            return foundBS;
        }
    }
    if(bs->next){
        if((foundBS = getBS(bs->next, searchid))){
            return foundBS;
        }
    }
    return NULL;
}

MobileHost * Tree::getMH(BaseStation * bs, int searchid){
    MobileHost * foundmh = NULL;
   
    if(out) // write visited nodes
    cout << bs->id << " ";
    
    // Search MHs of the current node
    MobileHost * mh = bs->mh;
    while(mh){
        if(mh->id == searchid){
            path_s.push(mh->id); // save path
            path_s.push(bs->id); // save path
            return mh;
        }
        mh = mh->next;
    }
    
    // if not found, go ahead with its subfolder then next folder
    if(bs->child){
        if((foundmh = getMH(bs->child, searchid))){
            path_s.push(bs->id); // save path
            return foundmh;
        }
    }
    if(bs->next){
        if((foundmh = getMH(bs->next, searchid))){
            return foundmh;
        }
    }
    
    return NULL;
}


void Tree::traversePreorder(BaseStation *bs){
    if (bs){
        cout << "BS:" << bs->id << endl;
        traversePreorder(bs->child);
        traversePreorder(bs->next);
    }
}

void printNetwork(BaseStation *bs, int level){
    if (bs){
        // process the node
        for (int i=0; i<level; i++) { cout << "\t"; }
        
        cout << "|BS:" << bs->id << " MHs:";
        
        MobileHost * mh = bs->mh;
        while(mh){
            cout << mh->id << " ";
            mh = mh->next;
        }
        
        cout << endl;
        
        printNetwork(bs->child, level+1);
        printNetwork(bs->next, level);
    }
}

bool searchNode(int id, Network net){
    bool found = false;
    path_s.makeEmpty();
    //cout << "\nSearching: " << id << endl;
    if(net.getMH(net.root, id))
        found = true;
    
    return found;
}


void readNetworkFile(string networkFile, Network net){
    ifstream infile(networkFile);
    string type;
    int id, pid;
    while (infile >> type >> id >> pid)
    {
        if(type.compare("BS") == 0){
            net.addBaseStation(id, pid);
        }else{ // MH
            net.addMobileHost(id, pid);
        }
    }
    infile.close();
}

void sendMessage(string msg, int targetid, Network net){
    cout << "Traversing:";
    if(searchNode(targetid, net)){ // if MH found
        cout << "\nMessage:" << msg << " To:";
        path_s.print();
    }else{ // if MH not found
        cout << "\nCan not be reached the mobile host mh_"<< targetid <<" at the moment";
    }
    
    
    cout << endl;
}

void processMessages(string messagesFile, Network net){
    ifstream infile(messagesFile);
    string str,msg;
    int targetid;
    string delim = ">";
    
    while (getline(infile, str)) {
        //cout << str << std::endl;
        msg = str.substr(0, str.find(delim));
        string tok = str.substr(str.find(delim)+1, str.size()-1);
        targetid = stoi(tok);
        
        sendMessage(msg, targetid, net);
    }
    
    
//    if (infile.is_open()) {
//        char c;
//        while (infile >> msg >> c >> targetid && c == '>')
//            cout << targetid << ":" << msg << "\n";
//    }
//    infile.close();
    
//    while (infile >> msg >> targetid)
//    {
//        msg = msg.substr(0, msg.size()-1);
//        sendMessage(msg, targetid, net);
//    }
    
}

// ------------------------------------------------

int main(int argc, const char * argv[]) {
    
    if(argc<3){
        cout << "\nLess than two arguments" << endl;
        return -1;
    }
    
//    cout << "argv[1]: " << argv[1] << endl;
//    cout << "argv[2]: " << argv[2] << endl << endl;
    
    // variables
    Network net;
    
    // initialize variables
    net.create();
    path_s.create();
    
    // read input file
    out = false;
    readNetworkFile(argv[1], net) ;
    
    //printNetwork(net.root, 0);
    
    // process message file
    //cout << "\n\n";
    out = true;
    processMessages(argv[2], net);
    
    
    //cout << endl << endl;
    return 0;
}


